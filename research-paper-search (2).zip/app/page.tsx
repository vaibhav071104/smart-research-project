"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ThemeProvider, createTheme } from "@mui/material/styles"
import { Container, Typography, Box, FormControl, InputLabel, Select, MenuItem, Card, CardContent } from "@mui/material"
import { School as SchoolIcon } from "@mui/icons-material"
import SearchBar from "./components/SearchBar"
import type { SearchRequest } from "./types"

const theme = createTheme({
  palette: {
    primary: {
      main: "#9333EA",
      light: "#A855F7",
      dark: "#7E22CE",
    },
  },
})

export default function Home() {
  const [query, setQuery] = useState("")
  const [year, setYear] = useState<string>("")
  const [api, setApi] = useState<SearchRequest["api"]>("semantic_scholar")
  const router = useRouter()

  const handleSearch = (searchQuery: string) => {
    if (!searchQuery.trim()) return
    router.push(`/search?query=${encodeURIComponent(searchQuery)}&year=${year}&api=${api}`)
  }

  return (
    <ThemeProvider theme={theme}>
      <Box
        sx={{
          minHeight: "100vh",
          background: "linear-gradient(135deg, #9333EA 0%, #A855F7 100%)",
          py: 8,
        }}
      >
        <Container maxWidth="lg">
          <Box sx={{ textAlign: "center", mb: 6 }}>
            <SchoolIcon sx={{ fontSize: 48, color: "white", mb: 2 }} />
            <Typography variant="h2" component="h1" sx={{ color: "white", mb: 2 }}>
              Research Paper Search
            </Typography>
            <Typography variant="h5" sx={{ color: "rgba(255, 255, 255, 0.9)" }}>
              Search across multiple academic databases
            </Typography>
          </Box>

          <Card sx={{ maxWidth: 800, mx: "auto", borderRadius: 4 }}>
            <CardContent sx={{ p: 4 }}>
              <Box sx={{ display: "flex", gap: 2, mb: 3 }}>
                <FormControl sx={{ minWidth: 120 }}>
                  <InputLabel>Year</InputLabel>
                  <Select value={year} label="Year" onChange={(e) => setYear(e.target.value as string)}>
                    <MenuItem value="">Any year</MenuItem>
                    {[...Array(30)].map((_, i) => (
                      <MenuItem key={i} value={`${new Date().getFullYear() - i}`}>
                        {new Date().getFullYear() - i}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>

                <FormControl sx={{ minWidth: 200 }}>
                  <InputLabel>Database</InputLabel>
                  <Select value={api} label="Database" onChange={(e) => setApi(e.target.value as SearchRequest["api"])}>
                    <MenuItem value="semantic_scholar">Semantic Scholar</MenuItem>
                    <MenuItem value="arxiv_papers">arXiv Papers</MenuItem>
                    <MenuItem value="doaj">DOAJ</MenuItem>
                  </Select>
                </FormControl>
              </Box>

              <SearchBar onSearch={handleSearch} setQuery={setQuery} api={api} />
            </CardContent>
          </Card>
        </Container>
      </Box>
    </ThemeProvider>
  )
}

