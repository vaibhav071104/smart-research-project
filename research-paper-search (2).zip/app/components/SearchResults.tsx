"use client"

import { Card, CardContent, Typography, Box, CircularProgress } from "@mui/material"
import type { Paper } from "../types"

interface SearchResultsProps {
  papers: Paper[]
  onPaperSelect: (paper: Paper) => void
  isLoading: boolean
}

export default function SearchResults({ papers, onPaperSelect, isLoading }: SearchResultsProps) {
  if (isLoading) {
    return (
      <Card>
        <CardContent>
          <Box sx={{ display: "flex", justifyContent: "center", p: 4 }}>
            <CircularProgress />
          </Box>
        </CardContent>
      </Card>
    )
  }

  if (papers.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography color="text.secondary" align="center">
            No papers found. Try adjusting your search.
          </Typography>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom>
          Search Results
        </Typography>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {papers.map((paper, index) => (
            <Card
              key={index}
              variant="outlined"
              sx={{
                cursor: "pointer",
                "&:hover": {
                  backgroundColor: "rgba(0, 0, 0, 0.04)",
                },
              }}
              onClick={() => onPaperSelect(paper)}
            >
              <CardContent>
                <Typography variant="subtitle1" gutterBottom>
                  {paper.title}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {paper.authors.join(", ")} • {paper.year}
                </Typography>
                <Typography variant="body2">{paper.abstract}</Typography>
              </CardContent>
            </Card>
          ))}
        </Box>
      </CardContent>
    </Card>
  )
}

