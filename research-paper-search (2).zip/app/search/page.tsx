"use client"

import { useSearchParams } from "next/navigation"
import { useState, useEffect } from "react"
import Link from "next/link"
import { ThemeProvider, createTheme, styled } from "@mui/material/styles"
import { Container, Typography, Card, CardContent, Box, IconButton, Breadcrumbs, Alert } from "@mui/material"
import { ArrowBack as ArrowBackIcon, Error as ErrorIcon } from "@mui/icons-material"
import type { Paper } from "../types"
import { performSearch } from "../utils/search"
import SearchResults from "../components/SearchResults"

const theme = createTheme({
  palette: {
    primary: {
      main: "#9333EA",
    },
  },
})

const GradientBackground = styled(Box)({
  minHeight: "100vh",
  background: "linear-gradient(135deg, #9333EA 0%, #A855F7 100%)",
  padding: "2rem 0",
})

export default function SearchResultsPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("query")
  const year = searchParams.get("year")
  const api = searchParams.get("api")

  const [papers, setPapers] = useState<Paper[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchResults = async () => {
      if (!query) return

      setIsLoading(true)
      setError(null)
      try {
        const results = await performSearch(query, year || "", api || "semantic_scholar")
        setPapers(results)
      } catch (err) {
        console.error("Search error:", err)
        setError(err instanceof Error ? err.message : "An error occurred while searching")
      } finally {
        setIsLoading(false)
      }
    }

    fetchResults()
  }, [query, year, api])

  return (
    <ThemeProvider theme={theme}>
      <GradientBackground>
        <Container maxWidth="lg">
          <Box sx={{ mb: 4 }}>
            <Link
              href="/"
              style={{
                color: "white",
                textDecoration: "none",
                display: "flex",
                alignItems: "center",
              }}
            >
              <IconButton size="small" sx={{ color: "white", mr: 1 }}>
                <ArrowBackIcon />
              </IconButton>
              Back to Search
            </Link>
          </Box>

          <Card sx={{ borderRadius: 2 }}>
            <CardContent>
              <Box sx={{ mb: 3 }}>
                <Typography variant="h5" gutterBottom>
                  Search Results
                </Typography>
                <Breadcrumbs separator="›">
                  <Typography color="text.secondary">Query: {query}</Typography>
                  {year && <Typography color="text.secondary">Year: {year}</Typography>}
                  <Typography color="text.secondary">Database: {api}</Typography>
                </Breadcrumbs>
              </Box>

              {error ? (
                <Alert
                  severity="error"
                  icon={<ErrorIcon />}
                  sx={{ borderRadius: 2, backgroundColor: "rgba(211, 47, 47, 0.05)" }}
                >
                  {error}
                </Alert>
              ) : (
                <SearchResults
                  papers={papers}
                  isLoading={isLoading}
                  onPaperSelect={(paper) => {
                    window.open(paper.url, "_blank", "noopener,noreferrer")
                  }}
                />
              )}
            </CardContent>
          </Card>
        </Container>
      </GradientBackground>
    </ThemeProvider>
  )
}

