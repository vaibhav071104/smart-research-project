import axios from "axios"
import type { Paper, SearchRequest, ReferenceRequest } from "../types"

const getApiUrl = () => (process.env.NODE_ENV === "production" ? process.env.NEXT_PUBLIC_API_URL : "")

export const performSearch = async (searchQuery: string, year: string, api: string): Promise<Paper[]> => {
  try {
    const response = await axios.post(`${getApiUrl()}/search_papers`, {
      query: searchQuery,
      year: year ? Number.parseInt(year) : undefined,
      api,
    } as SearchRequest)

    if (!response.data || !response.data.papers) {
      throw new Error("Invalid response from server")
    }

    return response.data.papers
  } catch (err) {
    console.error("Search error:", err)
    throw err
  }
}

export const fetchSuggestions = async (input: string, api: string): Promise<string[]> => {
  try {
    const response = await axios.get(`${getApiUrl()}/suggest`, {
      params: { q: input, api },
    })

    if (response.data.status === "error") {
      throw new Error(response.data.message || "Failed to fetch suggestions")
    }

    return response.data.suggestions
  } catch (err) {
    console.error("Error fetching suggestions:", err)
    throw err
  }
}

export const fetchReferences = async (paperId: string, depth: number): Promise<Paper[]> => {
  try {
    const response = await axios.post(`${getApiUrl()}/download_references`, {
      paper_id: paperId,
      depth,
    } as ReferenceRequest)

    if (!response.data || !response.data.references) {
      throw new Error("Invalid response from server")
    }

    return response.data.references
  } catch (err) {
    console.error("Error fetching references:", err)
    throw err
  }
}

