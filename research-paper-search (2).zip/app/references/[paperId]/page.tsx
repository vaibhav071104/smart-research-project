"use client"

import { useEffect, useState, useCallback } from "react"
import { useParams, useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { ThemeProvider, createTheme } from "@mui/material/styles"
import {
  Container,
  Typography,
  Card,
  CardContent,
  Box,
  IconButton,
  Button,
  Alert,
  CircularProgress,
  Chip,
} from "@mui/material"
import { ArrowBack as ArrowBackIcon, Article as ArticleIcon, CalendarToday as CalendarIcon } from "@mui/icons-material"
import type { Paper } from "@/app/types"
import { fetchReferences } from "@/app/utils/search"

const theme = createTheme({
  palette: {
    primary: {
      main: "#9333EA",
    },
  },
})

export default function PaperDetails() {
  const params = useParams()
  const searchParams = useSearchParams()
  const router = useRouter()
  const paperId = params.paperId as string
  const depth = searchParams.get("depth") || "1"

  const [paper, setPaper] = useState<Paper | null>(null)
  const [references, setReferences] = useState<Paper[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchPaperDetails = useCallback(async () => {
    setIsLoading(true)
    setError(null)

    try {
      const data = await fetchReferences(paperId, Number.parseInt(depth))
      if (data.length > 0) {
        setPaper(data[0])
        setReferences(data.slice(1))
      } else {
        throw new Error("No paper details found")
      }
    } catch (error) {
      console.error("Error fetching paper:", error)
      setError("Failed to fetch paper details. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }, [paperId, depth])

  useEffect(() => {
    fetchPaperDetails()
  }, [fetchPaperDetails])

  return (
    <ThemeProvider theme={theme}>
      <Box sx={{ minHeight: "100vh", bgcolor: "#f5f5f5", py: 4 }}>
        <Container maxWidth="lg">
          <Box sx={{ mb: 4 }}>
            <Link
              href="/references"
              style={{
                color: "inherit",
                textDecoration: "none",
                display: "flex",
                alignItems: "center",
              }}
            >
              <IconButton size="small" sx={{ mr: 1 }}>
                <ArrowBackIcon />
              </IconButton>
              Back to References
            </Link>
          </Box>

          {isLoading ? (
            <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}>
              <CircularProgress />
            </Box>
          ) : error ? (
            <Alert severity="error" sx={{ mb: 4 }}>
              {error}
            </Alert>
          ) : paper ? (
            <>
              <Card sx={{ mb: 4 }}>
                <CardContent>
                  <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2, mb: 3 }}>
                    <ArticleIcon sx={{ fontSize: 40, color: "primary.main" }} />
                    <Box sx={{ flex: 1 }}>
                      <Typography variant="h4" gutterBottom>
                        {paper.title}
                      </Typography>
                      <Box sx={{ display: "flex", gap: 1, mb: 2 }}>
                        <Chip icon={<CalendarIcon />} label={`Published in ${paper.year}`} size="small" />
                        {paper.venue && <Chip icon={<ArticleIcon />} label={paper.venue} size="small" />}
                      </Box>
                    </Box>
                  </Box>

                  <Typography variant="body1" paragraph>
                    {paper.abstract}
                  </Typography>

                  <Button variant="contained" href={paper.url} target="_blank" rel="noopener noreferrer">
                    View Paper
                  </Button>
                </CardContent>
              </Card>

              {references.length > 0 && (
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      References ({references.length})
                    </Typography>
                    <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                      {references.map((ref) => (
                        <Card key={ref.paperId} variant="outlined">
                          <CardContent>
                            <Typography variant="h6" gutterBottom>
                              {ref.title}
                            </Typography>
                            <Typography variant="body2" color="text.secondary" gutterBottom>
                              {ref.authors.join(", ")} • {ref.year}
                            </Typography>
                            <Typography variant="body2" paragraph>
                              {ref.abstract}
                            </Typography>
                            <Button
                              variant="outlined"
                              size="small"
                              onClick={() => router.push(`/references/${ref.paperId}?depth=${depth}`)}
                            >
                              View Details
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                    </Box>
                  </CardContent>
                </Card>
              )}
            </>
          ) : (
            <Alert severity="error">No paper data available</Alert>
          )}
        </Container>
      </Box>
    </ThemeProvider>
  )
}

